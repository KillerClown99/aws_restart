print("Python has three numeric types: int, float and complex")
Myvalue=1
print(Myvalue)
print(type(Myvalue))
print(str(Myvalue) + " is of the data type " + str(type(Myvalue)))


Myvalue1=3.14
print(Myvalue1)
print(type(Myvalue1))
print(str(Myvalue1) + " is of the data type " + str(type(Myvalue1)))

Myvalue=5j
print(Myvalue)
print(type(Myvalue))
print(str(Myvalue) + " is of the data type " + str(type(Myvalue)))

Myvalue = True
print(type(Myvalue))
print(str(Myvalue) + " is of the data type " + str(type(Myvalue)))

Myvalue=False
print(Myvalue)
print(type(Myvalue))
print(str(Myvalue) + " is of the data type " + str(type(Myvalue)))