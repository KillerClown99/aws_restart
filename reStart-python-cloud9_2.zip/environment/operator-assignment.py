# Addition
x = 15
y = 13
result = x + y
print("Addition result: ", result)

# Subtraction
x = 15
y = 13
result = x - y
print("Subtraction result: ", result)

# Multiplication
x = 15
y = 13
result = x * y
print("Multiplication result: ", result)

# Division
x = 15
y = 13
result = x / y
print("Division result: ", result)

# Floor Division
x = 15
y = 13
result = x // y
print("Floor Division result: ", result)

# Modulus
x = 15
y = 13
result = x % y
print("Modulus result: ", result)

# Exponentiation
x = 15
y = 13
result = x ** y
print("Exponentiation result: ", result)

# Equal to
x = 15
y = 15
result = x == y
print("Equal to result: ", result)

# Not equal to
x = 15
y = 13
result = x != y
print("Not equal to result: ", result)

# Greater than
x = 15
y = 13
result = x > y
print("Greater than result: ", result)

# Less than
x = 15
y = 13
result = x < y
print("Less than result: ", result)

# Greater than or equal to
x = 15
y = 15
result = x >= y
print("Greater than or equal to result: ", result)

# Less than or equal to
x = 15
y = 15
result = x <= y
print("Less than or equal to result: ", result)
